package com.softtek.mayo13Back;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mayo13BackApplication {

	public static void main(String[] args) {
		SpringApplication.run(Mayo13BackApplication.class, args);
	}

}
