package com.softtek.mayo7Refactorizacion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Mayo7RefactorizacionApplicationTests {

	@Test
	void contextLoads() {
	}

}
