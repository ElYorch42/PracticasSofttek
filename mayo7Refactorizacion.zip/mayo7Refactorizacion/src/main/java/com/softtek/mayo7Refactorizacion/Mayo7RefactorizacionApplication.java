package com.softtek.mayo7Refactorizacion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mayo7RefactorizacionApplication {

	public static void main(String[] args) {
		SpringApplication.run(Mayo7RefactorizacionApplication.class, args);
	}

}
