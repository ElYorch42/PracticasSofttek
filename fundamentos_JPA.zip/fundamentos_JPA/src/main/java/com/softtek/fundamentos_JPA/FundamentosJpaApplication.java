package com.softtek.fundamentos_JPA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FundamentosJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(FundamentosJpaApplication.class, args);
	}

}
