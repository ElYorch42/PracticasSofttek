package com.softtek.mayo7;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mayo7Application {

	public static void main(String[] args) {
		SpringApplication.run(Mayo7Application.class, args);
	}

}
